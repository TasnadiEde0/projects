public class ChatIDData extends Data{
    public int chatID;
    public ChatIDData(int chatID) {
        this.chatID = chatID;
    }

}
