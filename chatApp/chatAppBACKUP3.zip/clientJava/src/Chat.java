import java.util.List;

public class Chat extends Data{
    public int chatID;
    public List<User> userList;
    public List<Message> messageHistory;
}
