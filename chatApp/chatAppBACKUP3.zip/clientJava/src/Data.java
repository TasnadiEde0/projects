abstract class Data {
}