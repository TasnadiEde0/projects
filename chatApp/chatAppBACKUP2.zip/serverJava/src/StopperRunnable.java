import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StopperRunnable implements Runnable{
    private List<Client> clients;
    private Server server;
    private List<Chat> chatList;
    private List<User> userList;

    public StopperRunnable(List<Client> clients, Server server){
        this.clients = clients;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            Scanner scanner = new Scanner(System.in);
            while(true) {
                String input = scanner.nextLine();
                if(input.equals("EXIT")) {
























                }
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
