import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws Exception {

        Server server = new Server();
        List<Thread> clientThreads = new ArrayList<>();
        List<Client> clients = new ArrayList<>();
        List<Chat> chatList = new ArrayList<>();
        List<User> userList = new ArrayList<>();

        Thread stopperThread = new Thread();

        while(true) {
            Socket clientSocket = server.acceptClient();
            Client client = new Client(clientSocket, chatList, clients);
            ClientThread receiverThread = new ClientThread(client, chatList, userList, clients);
            Thread receiveThread = new Thread(receiverThread);
            receiveThread.start();

            clients.add(client);
            clientThreads.add(receiveThread);

        }
    }

    public static void database() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String jdbcUrl = "jdbc:sqlserver://localhost:1433;integratedSecurity=true;databaseName=AdventureWorks2022;encrypt=true;trustServerCertificate=true";

            Connection connection = DriverManager.getConnection(jdbcUrl);

            System.out.println("Connected to the database!");

            Statement statement = connection.createStatement();
            String query = "SELECT * FROM Person.Person";
            java.sql.ResultSet resultSet =  statement.executeQuery(query);
            while (resultSet.next()) {
                // Access data from each row
                String username = resultSet.getString("FirstName");
                int email = resultSet.getInt("EmailPromotion");
                // You can access other columns similarly
                System.out.println("Username: " + username + ", Email: " + email);
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}