public class Message extends Data{
    public int authorID;
    public String authorName;
    public String date;
    public String text;
    public int chatID;
}
