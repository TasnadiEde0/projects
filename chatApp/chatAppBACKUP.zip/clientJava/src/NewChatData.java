public class NewChatData extends Data{
    public Chat newChat;
    public NewChatData(Chat newChat){
        this.newChat = newChat;
    }
}
