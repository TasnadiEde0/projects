public class ChatRequestData extends Data{
    public String name;
    public ChatRequestData(String name) {
        this.name = name;
    }
}
