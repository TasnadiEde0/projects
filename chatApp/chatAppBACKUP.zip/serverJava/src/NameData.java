public class NameData extends Data{
    public String name;
    public NameData() {
        name = "";
    }
    public NameData(String name) {
        this.name = name;
    }

}
