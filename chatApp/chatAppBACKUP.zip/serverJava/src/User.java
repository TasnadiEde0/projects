public class User{
    public int userID;
    public String name;
    public Client client;
}
