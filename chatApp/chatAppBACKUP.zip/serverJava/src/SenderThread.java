import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;
import java.util.Scanner;

public class SenderThread implements Runnable{
    private Client client;
    private List<Chat> chatList;
    private List<User> userList;

    public SenderThread(Client client, List<Chat> chatList, List<User> userList){
        this.client = client;
        this.chatList = chatList;
        this.userList = userList;
    }

    @Override
    public void run() {
        try {
            GsonBuilder gsonBuilder = new GsonBuilder();
            gsonBuilder.registerTypeAdapter(DataPacket.class, new DataTypeAdapter());
            Gson gson = gsonBuilder.create();

            while (true) {





            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
