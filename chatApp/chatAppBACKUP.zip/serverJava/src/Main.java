import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Main {

    public static void main(String[] args) throws Exception {
        Server server = new Server();
        List<Thread> sendThreads = new ArrayList<>();
        List<Thread> receiveThreads = new ArrayList<>();
        List<Client> clients = new ArrayList<>();
        List<Chat> chatList = new ArrayList<>();
        List<User> userList = new ArrayList<>();

        while(true) {
            Socket clientSocket = server.acceptClient();
            Client client = new Client(clientSocket, chatList, clients);
            ReceiverThread receiverThread = new ReceiverThread(client, chatList, userList, clients);
            Thread receiveThread = new Thread(receiverThread);
            receiveThread.start();

            clients.add(client);
//            sendThreads.add(sendThread);
            receiveThreads.add(receiveThread);



        }

    }



















































    public void database() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String jdbcUrl = "jdbc:sqlserver://localhost:1433;integratedSecurity=true;databaseName=AdventureWorks2022;encrypt=true;trustServerCertificate=true";

            Connection connection = DriverManager.getConnection(jdbcUrl);

            System.out.println("Connected to the database!");

        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}