import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Server {

    private ServerSocket serverSocket;
    private int chatCount;

    public Server() throws IOException {
        serverSocket = new ServerSocket(12000);
        chatCount = 0;
    }

    public Socket acceptClient() throws IOException {
        return serverSocket.accept();
    }

    public int giveUniqueChatID() {
        chatCount++;
        return chatCount;
    }

}
