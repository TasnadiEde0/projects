import com.google.gson.Gson;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import static java.lang.System.exit;

public class ClientThread implements Runnable{
    private Client client;
    private Chat chat;

    public ClientThread(Client client, Chat chat){
        this.client = client;
        this.chat = chat;
    }
    @Override
    public void run() {
        try {



















        } catch (Exception e) {
            System.out.println(e);
            exit(1);
        }
    }
}
