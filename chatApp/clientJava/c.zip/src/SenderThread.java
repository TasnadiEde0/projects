import java.util.Scanner;
import com.google.gson.Gson;

public class SenderThread implements Runnable{
    private Client client;

    public SenderThread(Client client){
        this.client = client;
    }

    @Override
    public void run() {
        try {
            Scanner scanner = new Scanner(System.in);
            Gson gson = new Gson();
            while (true) {
                String messageText = scanner.nextLine();

                Message message = new Message();
                message.text = messageText;
                message.authorID = client.user.userID;
                message.date = "";

                String jsonMessage = gson.toJson(message);
                client.writer.println(jsonMessage);




            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
