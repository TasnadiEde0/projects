public class Message extends Data{
    public int authorID;
    public String date;
    public String text;
}
