import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

//Scanner scanner = new Scanner(System.in);
//String message = scanner.nextLine();

public class Main {

    public static void main(String[] args) throws IOException {

        Client client = new Client();
        client.user.userID = 0;
        client.user.name = "Ede";

        SenderThread senderThread = new SenderThread(client);
        ReceiverThread receiverThread = new ReceiverThread(client);
        Thread sendThread = new Thread(senderThread);
        Thread receiveThread = new Thread(receiverThread);
        sendThread.start();
        receiveThread.start();






    }

    void client() {
        try {
            Socket socket = new Socket("localhost", 12000);

            System.out.println("connected");

            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();

            Message msg = new Message();
            msg.authorID = 01;
            msg.date = "1970.01.01 3:00";
            msg.text = "Szia!";


            Gson gson = new Gson();
            String message = gson.toJson(msg);

            PrintWriter writer = new PrintWriter(outputStream, true);
            writer.println(message);

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            message = reader.readLine();

            msg = gson.fromJson(message, Message.class);

            System.out.println(message);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}