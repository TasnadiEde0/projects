public class Chat extends Data{
    public User[] userList;
    public Message[] messageHistory;
}
