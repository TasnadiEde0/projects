public class DataPacket {
    public int senderID = -1;
    public int receiverID = -1;
    public Data content;
}
