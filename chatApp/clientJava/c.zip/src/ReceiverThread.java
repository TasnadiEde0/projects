import com.google.gson.Gson;

public class ReceiverThread implements Runnable{
    private Client client;

    public ReceiverThread(Client client){
        this.client = client;
    }

    @Override
    public void run() {
        try {
            Gson gson = new Gson();
            while (true) {
                String jsonMessage = client.reader.readLine();

                Message message = gson.fromJson(jsonMessage, Message.class);
                System.out.println(message.authorID + ": " + message.text);
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }
}
